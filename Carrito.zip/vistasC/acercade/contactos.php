<div class="banner banner-second">
        <div class="banner-container ">
            <h1>La marca</h1>
            <h2>Slogan de la compañia</h2>
        </div>
    </div>
    <div class="container">
        
        <div class="columns">
            <div class="column is-half">
                
            </div>
            <div class="column is-half">
                <h3 class="has-text-weight-bold">Teléfono</h3>
                <p>7367-9491</p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="columns">
            <div class="column is-half">
            <img src="../img/logo.png">

            </div>
            <div class="column is-half">

                
                <h3 class="has-text-weight-bold">Correo</h3>
                <p>Chabastienda@gmail.com</p>
            </div>
        </div>
    </div>