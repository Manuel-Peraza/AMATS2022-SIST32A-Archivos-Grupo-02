<body>
    <!-- Banner -->
    <div class="banner banner-second">
        <div class="banner-container ">
            <h1>La marca</h1>
            <h2>Slogan de la compañia</h2>
        </div>
    </div>
    <div class="container">
        <div class="columns">
            <div class="column is-half">
                <img src="../img/logo.png" alt="">
            </div>
            <div class="column is-half">
                <h3 class="has-text-weight-bold">Misión </h3>
                <p>“Nuestra misión tiene a fin de tener el estilo y las prendas adecuada para tus eventos más importantes, de trabajo, fiestas, bodas, graduaciones y nosotros te ayudamos a descubrir el buen vestir para ti y tu familia con la ayuda del internet y la tecnología maximizamos tu experiencia al comprar tus productos.”  </p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="columns">
            <div class="column is-half">
                <h3 class="has-text-weight-bold">Visión</h3>
                <p>“Nuestra visión es puesta en la comodidad de nuestros consumidores, somos una empresa centrada en la confianza y en la experiencia de comprar en línea nuestros productos.” </p>
            </div>

        </div>
    </div>



    <script src="js/main.js"></script>
</body>