<?php 
$obj = new cls_producto();
//var_dump($_SESSION["CAR"]);
unset($_SESSION["factura"]);

?>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h1>Productos</h1>
			<br><br>
		</div>
	</div>
<?php

if (empty($_SESSION["CAR"])) {
	?>
	<center>
<br><br><br>
        <h3 class="text-center all-tittles">Vaya parece que no hay productos en tu carrito</h3>
        <h2 class="text-center"><i class="zmdi zmdi-mood-bad zmdi-hc-5x"></i><br><br>Intenta agregar <strong>productos</strong> a tu carrito</h2>
        <div class="modal fade" tabindex="-1" role="dialog" id="ModalHelp">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title text-center all-tittles">ayuda del sistema</h4>
                </div>
                <div class="modal-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore dignissimos qui molestias ipsum officiis unde aliquid consequatur, accusamus delectus asperiores sunt. Quibusdam veniam ipsa accusamus error. Animi mollitia corporis iusto.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="zmdi zmdi-thumb-up"></i> &nbsp; De acuerdo</button>
                </div>
            </div>
          </div>
        </div>
        </center>
	
	
	<?php
}else {
	

?>
	<form method="POST">
	<table class="table table-bordered">
		<thead>
			<th>Producto</th>
			<th>cantidad</th>
			<th>Precio</th>
			<th>Total Producto</th>
		</thead>
		<tbody>
		
		<?php

		@session_start();
		$carritoVenta = $_SESSION["CAR"];
		$totalProductos = "";
		$total = 0;
		$v = "";
		$ids['ids'] = "";
		foreach($carritoVenta  as $id=>$valor){
			$totalProductos = $valor[1]*$valor[0];
			$total += $totalProductos; 
			$format1 = number_format($valor[1]*$valor[0], 2);
			$format2 = number_format($valor[1], 2);
			$v = $valor[0];
			$ids['ids'] = $valor[2];
		
		?>
		<tr taskId="<?php echo $id;?>"><td ><?php echo $id;?><input type="text" hidden name="" value="<?php echo $id;?>" id="nombrer"></td>
		
		
		<?php
		echo "
		<td>$valor[0]
		</td>
		<td>\$$format2</td>
		<td>\$".$format1."</td>"?>
		<td><button class="btn btn-outline-danger" type="submit" id="eliminar">Eliminar</button></td>
		</tr>
		<?php 
		}
		
		$format = number_format($total, 2);
		?>
		<th colspan="4">Total: $<?php echo $format;?></th>
		
		</tbody>

	</table>
	</form>
	<form id="contenidocarrito">
	<button class="btn btn-outline-dark" type="submit">Pagar</button>
</form>
</div>
</body>
</html>
<?php
}
?>