<?php
@session_start();

if (@$_GET['codigo']!="") {
    $ObjProducto = new cls_producto();
$dato = $_GET['codigo'];
$datos = $ObjProducto->DetalleProducto($dato);

/*
    echo "<pre>";
    var_dump($_SESSION["CAR"]);
    echo "</pre>";
//unset($_SESSION["CAR"]);
//unset($_SESSION["carrito"]);

*/
?>
<body>

    <!-- Banner -->
    <div class="banner banner-second">
        <div class="banner-container ">
            <h1>La marca</h1>
            <h2>Slogan de la compañia</h2>
        </div>
    </div>
    <script src="<?php echo URLC;?>js/main2.js"></script>
    
    <script
      src="https://code.jquery.com/jquery-3.3.1.min.js"
      integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
    <div class="container">
        <div class="columns">
            <div class="column is-two-fifths-desktop">
                <div class="slider" id="slider">
                    <div class="slider-img-container">
                        <img src="../Admin/uploads/<?php echo $datos[5]?>" alt="camiseta" class="active slider-item">
                    </div>
                    <div class="slider-img-container">
                        <img src="../img/item-2.png" alt="camiseta" class="slider-item">
                    </div>
                    <div class="slider-img-container">
                        <img src="img/item-5.png" alt="camiseta" class="slider-item">
                    </div>
                    <div class="slider-button-left slider-buttons" onclick="previus()">
                        <i class="zmdi zmdi-chevron-left zmdi-hc-3x"></i>
                    </div>
                    <div class="slider-button-right slider-buttons" onclick="next()">
                        <i class="zmdi zmdi-chevron-right zmdi-hc-3x"></i>
                    </div>
                </div>
            </div>
            <div class="column">
                <h3 class="is-size-4"><?php echo $datos[0]?></h3>
                <input hidden type="number" name="" value="<?php echo $datos[7]?>" id="id">
                <div class="course-rating-container">
                    <div class="rating-stars" style="--rating: 86%">
                    </div>
                </div>
                <p class=""> 3 comentarios | Compartir: <a class="icon-socials" href="#"><i
                            class="zmdi zmdi-facebook"></i></a>
                    <a class="icon-socials" href="#"><i class="zmdi zmdi-twitter"></i></a>
                    <a class="icon-socials" href="#"><i class="zmdi zmdi-instagram"></i></a>
                    <a class="icon-socials" href="#"><i class="zmdi zmdi-pinterest"></i></a>
                    <a class="icon-socials" href="#"><i class="zmdi zmdi-email"></i></a>
                </p>
                <h2 class="price is-size-4"><sup>$</sup><?php echo $datos[1]?></h2>
                <p class="has-text-grey"> <strong>Disponibilidad: </strong><?php echo $datos[3]?> 
                <?php if ($datos[3] > 0) {
                    echo "En stock";
                }else {
                    echo "Agotado";
                }?> </p>
                <p class="has-text-grey"><strong>Código del procuto: </strong>#<?php echo $datos[6]?></p>
                <p class="text-default"><?php echo $datos[4]?></p>
                <form id="aggCarrito">
                    <div class="columns is-multiline">
                       
                        <div class="column is-one-third">
                            <label for="quality">Cantidad</label>  
                            <select class="form-group-input" id="cantidad">
                            <?php
                            $a = 1;
                            while ($a <= $datos[3]) {
                                ?><option  value="<?php echo $a;?>"><?php echo $a;?></option><?php
                                $a++;
                            }
                            ?>
                            
                            </select>
                        </div>
                        <div class="column is-full is-marginless">
                            <?php 
                            if ($datos[3] > 0) {
                                echo "<button type='submit' class='btn btn-default btn-outline'><i class='zmdi zmdi-shopping-cart'></i>
                                Agregar al carrito
                                <br>
                            </button>  ";
                            }
                            ?>
                             
                        </div>
                        <br>
                    </div>


        


                </form>
            </div>

        </div>
    </div>
    <div class="container">

        
    </div>
    
<?php }
else{ ?>
  <center>
<br><br><br>
        <h3 class="text-center all-tittles">No hay producto que mostrar</h3>
        <h2 class="text-center"><i class="zmdi zmdi-mood-bad zmdi-hc-5x"></i><br><br>Lo sentimos, no hemos encontrado ningún producto <strong>ingresado</strong> en el sistema</h2>
        <div class="modal fade" tabindex="-1" role="dialog" id="ModalHelp">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title text-center all-tittles">ayuda del sistema</h4>
                </div>
                <div class="modal-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore dignissimos qui molestias ipsum officiis unde aliquid consequatur, accusamus delectus asperiores sunt. Quibusdam veniam ipsa accusamus error. Animi mollitia corporis iusto.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="zmdi zmdi-thumb-up"></i> &nbsp; De acuerdo</button>
                </div>
            </div>
          </div>
        </div>
        </center>
  <?php
}

?>

<?php
if(isset($_POST['okk'])){

    //unset($_SESSION["CAR"]);
    //unset($_SESSION["carrito"]);
    unset($_SESSION["comprador"]);
}
?>