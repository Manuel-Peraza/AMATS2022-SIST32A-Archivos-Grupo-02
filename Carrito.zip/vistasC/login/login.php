
    <!-- Banner -->
    <div class="banner banner-second">
        <div class="banner-container ">
            <h1>La marca</h1>
            <h2>Slogan de la compañia</h2>
        </div>
    </div>
<form action="<?php echo URLC;?>LoginCliente/" method="post">
    <div class="container">
        <div class="columns">
            <div class="column">
                <h2 class="is-size-4">Iniciar seción</h2>
                <form action="#" class="form-control">

                    <input type="email" name="user" placeholder="Email" class="form-control-field error">

                    <input type="password" name="clave" placeholder="Password" class="form-control-field">

                    <button type="submit" class="btn btn-default btn-primary">Iniciar seción</button>
                </form>
            </div>
        </div>
    </div>
    </form>
    <script src="js/main.js"></script>


