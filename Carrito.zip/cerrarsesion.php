<?php
unset($_SESSION["comprador"]);
unset($_SESSION["CAR"]);
unset($_SESSION["carrito"]);
?>