<?php
/// Powered by Evilnapsis go to http://evilnapsis.com
@session_start();
unset($_SESSION["CAR"]);
include ("./fpdf.php");
include('../librerias/config.php');
include('../librerias/database.php');
include('../clases/cls_compra.php');

if (isset($_SESSION['factura'])) {
    if (isset($_SESSION['comprador'])) {
        # code...
    
    foreach ($_SESSION['comprador'] as $key => $value) {
        $v['dat'] = $value[0];
    }
    $objId = new cls_compra();
    $id = $objId->idfactura($v);
    if ($id ==1) {
        echo "no tiene facturas";
    }else{
        
        date_default_timezone_set('America/El_Salvador');
        $pdf = new FPDF($orientation='P',$unit='mm');
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',20);    
        $textypos = 5;
        $pdf->setY(12);
        $pdf->setX(10);
        // Agregamos los datos de la empresa
        $pdf->Cell(5,$textypos,"Chaba's");
        $pdf->SetFont('Arial','B',10);    
        $pdf->setY(30);$pdf->setX(10);
        $pdf->Cell(5,$textypos,"DE:");
        $pdf->SetFont('Arial','',10);
        $pdf->setY(35);$pdf->setX(10);
        $pdf->Cell(5,$textypos,"Nombre de la empresa");
        $pdf->setY(40);$pdf->setX(10);
        $pdf->Cell(5,$textypos,"Direccion de la empresa");
        $pdf->setY(45);$pdf->setX(10);
        $pdf->Cell(5,$textypos,"Telefono de la empresa");
        $pdf->setY(50);$pdf->setX(10);
        $pdf->Cell(5,$textypos,"Email de la empresa");
        
        // Agregamos los datos del cliente
        $pdf->SetFont('Arial','B',10);    
        $pdf->setY(30);$pdf->setX(75);
        $pdf->Cell(5,$textypos,"PARA:");
        $pdf->SetFont('Arial','',10);    
        $pdf->setY(35);$pdf->setX(75);
        $pdf->Cell(5,$textypos,"Nombre del cliente");
        $pdf->setY(40);$pdf->setX(75);
        $pdf->Cell(5,$textypos,"Direccion del cliente");
        $pdf->setY(45);$pdf->setX(75);
        $pdf->Cell(5,$textypos,"Telefono del cliente");
        $pdf->setY(50);$pdf->setX(75);
        $pdf->Cell(5,$textypos,"Email del cliente");
        
        // Agregamos los datos del cliente
        $pdf->SetFont('Arial','B',10);    
        $pdf->setY(30);$pdf->setX(135);
        $pdf->Cell(5,$textypos,"FACTURA #".$id."");
        $pdf->SetFont('Arial','',10);    
        $pdf->setY(35);$pdf->setX(135);
        $pdf->Cell(5,$textypos,$DateAndTime = date('m-d-Y h:i:s a', time()));
        $pdf->setY(40);$pdf->setX(135);
        $pdf->Cell(5,$textypos,"");
        $pdf->setY(45);$pdf->setX(135);
        $pdf->Cell(5,$textypos,"");
        $pdf->setY(50);$pdf->setX(135);
        $pdf->Cell(5,$textypos,"");
        
        /// Apartir de aqui empezamos con la tabla de productos
        $pdf->setY(60);$pdf->setX(135);
            $pdf->Ln();
        /////////////////////////////
        //// Array de Cabecera
        $header = array("Cod.", "Descripcion","Cant.","Precio","Total");
        //// Arrar de Productos
        $cont = count($_SESSION["factura"]);
        $c = 1;
        $products = array();
        $cart = $_SESSION["factura"];
        foreach ($cart as $id => $value) {
            $products[] = array(   
                $value[2], $id,$value[0],$value[1],0,
            );
        }
            
        
        
            // Column widths
            $w = array(20, 95, 20, 25, 25);
            // Header
            for($i=0;$i<count($header);$i++)
                $pdf->Cell($w[$i],7,$header[$i],1,0,'C');
            $pdf->Ln();
            // Data
            $total = 0;
            foreach($products as $row)
            {
                $pdf->Cell($w[0],6,$row[0],1);
                $pdf->Cell($w[1],6,$row[1],1);
                $pdf->Cell($w[2],6,number_format($row[2]),'1',0,'R');
                $pdf->Cell($w[3],6,"$ ".number_format($row[3],2,".",","),'1',0,'R');
                $pdf->Cell($w[4],6,"$ ".number_format($row[3]*$row[2],2,".",","),'1',0,'R');
        
                $pdf->Ln();
                $total+=$row[3]*$row[2];
        
            }
        /////////////////////////////
        //// Apartir de aqui esta la tabla con los subtotales y totales
        $yposdinamic = 60 + (count($products)*10);
        
        $pdf->setY($yposdinamic);
        $pdf->setX(235);
            $pdf->Ln();
        /////////////////////////////
        $header = array("", "");
        $data2 = array(
            array("Subtotal",$total),
            array("Descuento", 0),
            array("Impuesto", 0),
            array("Total", $total),
        );
            // Column widths
            $w2 = array(40, 40);
            // Header
        
            $pdf->Ln();
            // Data
            foreach($data2 as $row)
            {
        $pdf->setX(115);
                $pdf->Cell($w2[0],6,$row[0],1);
                $pdf->Cell($w2[1],6,"$ ".number_format($row[1], 2, ".",","),'1',0,'R');
        
                $pdf->Ln();
            }
        /////////////////////////////
        
        $yposdinamic += (count($data2)*10);
        $pdf->SetFont('Arial','B',10);    
        
        $pdf->setY($yposdinamic);
        $pdf->setX(10);
        $pdf->Cell(5,$textypos,"TERMINOS Y CONDICIONES");
        $pdf->SetFont('Arial','',10);    
        
        $pdf->setY($yposdinamic+10);
        $pdf->setX(10);
        $pdf->Cell(5,$textypos,"El cliente se compromete a pagar la factura.");
        $pdf->setY($yposdinamic+20);
        $pdf->setX(10);
        $pdf->Cell(5,$textypos,"Powered by Evilnapsis");
        
        
        $pdf->Output();
        //$pdf->Output("invoice.pdf", "D");
    }
    
    }else {
        echo "Inicie Sesión";
    }
}else{
    echo "No hay factura que mostrar";
}


?>