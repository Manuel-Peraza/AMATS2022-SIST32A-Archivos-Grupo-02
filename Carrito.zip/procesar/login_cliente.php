<h1>CACACACACacadsa</h1>
<?php


@session_start();

    $objPersona=new cls_users() ;
$objEncriptar_desencriptar=new cls_encriptar_desencriptar();
$datos[]=$_POST["user"];
$datos[]=$objEncriptar_desencriptar->encriptar_desencriptar("encriptar",$_POST["clave"]);
$datosUser = $objPersona->login($datos);





if ($datosUser) {
    $roles[] = $datosUser[0];
    $roles[]=$datosUser[1]; 
    $_SESSION["comprador"]=$roles;
}
    

?>
