<?php

include("../js/database.php");
@session_start();
$search = $_POST['id'];
$cantidad = $_POST['cantidad'];
if(!empty($search)) {
  $query = "SELECT * FROM productos WHERE idproducto = '$search'";
  $result = mysqli_query($connection, $query);
  
  if(!$result) {
    die('Query Error' . mysqli_error($connection));
  }elseif ($result) {
    $nombre = array();
  $json = array();
  $datos = array();
  $nomp = array();
  while($row = mysqli_fetch_array($result)) {
    $nomp['nom'] = $row['nombre_producto'];
    $json[] = $cantidad;
    $json[] = $row['precio_normal'];
    $json[] = $search;
  }
  
//se insertan los productos a la session por producto
$nombre[$nomp['nom']]=$json;
$_SESSION["carrito"]=$nombre;
      





$datosGuardados = $_SESSION["carrito"];
$carritoVenta = $_SESSION["CAR"];



    $v = "";
    $v1 = "";
    $v2 = "";
    $v3 = "";
    foreach($datosGuardados as $id=>$valor){

      $v = $id;
      $v1 = $valor[0];
      $v2 = $valor[1];
      $v3 = $valor[2];
    }

    

    
    if(isset($_SESSION["CAR"])){
        $nombres=$_SESSION["CAR"];
        $nom=$v;
        $datost[]=$v1;
        $datost[]=$v2;
        $datost[]=$v3;
        $datost[]=number_format($v1*$v2,2);
        $datost[]=date(' h:i:s a', time());
        $nombres[$nom]=$datost;
        $_SESSION["CAR"]=$nombres;
      }
      else{
        //se crea la sesion 
        
        $nom=$v;
        $datostx[]=$v1;
        $datostx[]=$v2;
        $datostx[]=$v3;
        $datost[]=number_format($v1*$v2,2);
        $datost[]=date(' h:i:s a', time());
        $nombre[$nom]=$datostx;
        $_SESSION["CAR"]=$nombre;
    }




    $json1 = array();
    $carritoVenta = $_SESSION["CAR"];
    foreach($_SESSION["CAR"] as $id=>$valors){
      $json1[] = array(
        'name' =>$id,
        'dato'=>$valors[0],
        'iden' => $valors[1]
      );
    }

     
      $jsonstring = json_encode($json1);
      echo 1;
  //unset($_SESSION["carrito"]);
  }else{
    echo 0;
  }
  
}
?>