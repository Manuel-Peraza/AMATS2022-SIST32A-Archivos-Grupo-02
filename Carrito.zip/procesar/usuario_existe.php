<?php
@session_start();

if (isset($_SESSION['comprador'])) {
    echo 1;
}else {
    echo 0;
}


?>