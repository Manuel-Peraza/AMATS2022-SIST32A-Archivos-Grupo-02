<?php

$objPersona=new cls_users();
$objEncriptar_desencriptar=new cls_encriptar_desencriptar();

$datos["nombre"]=$_POST["nombre"];
$datos["email"]=$_POST["email"];
$datos["clave"]=$objEncriptar_desencriptar->encriptar_desencriptar("encriptar",$_POST["clave"]);

$objPersona->agregar($datos);



?>