<?php
include('../librerias/database.php');
$buscar = $_POST['buscar'];
if(!empty($buscar)){

$sql = "SELECT nombre_producto,idproducto FROM productos WHERE nombre_producto LIKE '%$buscar%'";
$consulta = mysqli_query($connection,$sql);
if(!$consulta) {
    die('Query Failed'. mysqli_error($connection));
  }
$json = array();
while ($row = mysqli_fetch_array($consulta)) {
    $json[] = array(
    'nombre_producto' => $row['nombre_producto'],
    'idproducto' => $row['idproducto']

    );
}

$jsonstring = json_encode($json);
echo $jsonstring;


}




?>