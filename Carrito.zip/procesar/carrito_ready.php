<?php
include("../js/database.php");
require_once("./actualizar_carrito.php");
//require_once("../procesar/actualizar_carrito.php");
@session_start();




$v = array();
$v1 = array();
$json1 = array();
$carritoVenta = $_SESSION["CAR"];
foreach($_SESSION["CAR"] as $id=>$valor){
  $json1[] = array(
    'name' =>$id,
    'dato'=>$valor['0'],
    'precio'=>$valor['1'],
    'total' => $valor['0'] * $valor['1'],
    'id' => $valor['2']
  );
}





$jsonstring = json_encode($json1);
echo $jsonstring;

  
      
?>