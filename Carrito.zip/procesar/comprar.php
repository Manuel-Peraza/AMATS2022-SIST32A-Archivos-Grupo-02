<?php
@session_start();
include('../librerias/config.php');
include('../librerias/database.php');
include('../librerias/cls_encriptar_desencriptar.php');
include('../clases/cls_personas.php');
//echo $_POST['user'];

if(!(isset($_SESSION["comprador"]))){
    $objPersona=new cls_users() ;
$objEncriptar_desencriptar=new cls_encriptar_desencriptar();
$datos['user']=$_POST['user'];
$datos['clave']=$objEncriptar_desencriptar->encriptar_desencriptar("encriptar",$_POST['clave']);
$datosUser = $objPersona->login($datos);




if($datosUser){
    $roles[] = $datosUser[0];
    $roles[]=$datosUser[1]; 
    $_SESSION["comprador"]=$roles;
    //header("location:".URL."");
    echo 1;
}else{
    echo 2;
    //echo "<script>alert('Nombre de universidad registrado')</script>";
   //header("location:".URL."login");
}
}else{
    echo 3;
}




?>