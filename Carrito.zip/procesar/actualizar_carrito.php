<?php
@session_start();
include('../librerias/config.php');
include('../librerias/database.php');
include('../librerias/cls_encriptar_desencriptar.php');
include('../clases/cls_producto.php');





if (isset($_POST['nombre'])) {
     $nombrer = $_POST['nombre'];
    foreach($_SESSION["CAR"] as $idr=>$valors){
            
        if ($nombrer == $idr){
            unset($_SESSION["CAR"][$idr]);
        }
    }
}



?>