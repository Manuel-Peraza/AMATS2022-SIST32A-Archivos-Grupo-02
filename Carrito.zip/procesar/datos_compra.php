<?php
@session_start();
date_default_timezone_set('America/El_Salvador');
include('../librerias/config.php');
include('../librerias/database.php');
include('../clases/cls_compra.php');
include('../clases/cls_producto.php');
/*******************Ingresa a pedidos *****************/
$ObjCompra = new cls_compra();
$Objresta = new cls_compra();
$ObjProductoactua = new cls_producto();
//echo $_POST['name'];
//echo $_POST['numero'];
//echo $_POST['CV'];
//echo $_POST['clave'];
//




$v = "";
foreach ($_SESSION['comprador'] as $key => $value) {
    $v = $value[0];
}

$carritoVenta = $_SESSION["CAR"];
$totalProductos = "";
$total = 0;
foreach($carritoVenta  as $id=>$valor){
	$totalProductos = $valor[1]*$valor[0];
	$total += $totalProductos; 

}

$format = number_format($total, 2);

$datos['idCliente'] = $v;
$datos['fecha'] = $DateAndTime = date('y-m-d h:i:s a', time());
$datos['total'] = $format;

$idpedido = $ObjCompra->insertarfactura($datos);

if ($idpedido) {

            $carritoVenta2 = $_SESSION["CAR"];

        foreach($carritoVenta2  as $id2=>$valor2){

        $datex = $ObjProductoactua->DetalleProducto($valor2[2]);

        $resta = $datex[3]-$valor[0];

	$datos2['idproducto'] = $valor2[2];
    $datos2['cantidad'] = $valor2[0];
    $datos2['subtotal'] = $valor2[3];
    $datos2['idpedido'] = $idpedido;

    

    $restas['cantidad'] = $resta;
    $restas['idproducto'] = $valor2[2];



    $ObjCompra->detallepedido($datos2);
    
    $Objresta->restacantidad($restas);

    
}

//unset($_SESSION["CAR"]);


$datosGuardados = $_SESSION["CAR"];




    $v = "";
    $v1 = "";
    $v2 = "";
    $v3 = "";
    $v4 = "";
    foreach($datosGuardados as $id=>$valor){

      $v = $id;
      $v1 = $valor[0];
      $v2 = $valor[1];
      $v3 = $valor[2];
      $v4 = $valor[3];
    }

    

    
    if(isset($_SESSION["factura"])){
        $nombres=$_SESSION["factura"];
        $nom=$v;
        $datost[]=$v1;
        $datost[]=$v2;
        $datost[]=$v3;
        $datost[]=$v4;
        $datost[]=number_format($v1*$v2,2);
        $nombres[$nom]=$datost;
        $_SESSION["factura"]=$nombres;
      }
      else{
        //se crea la sesion 
        
        $nom=$v;
        $datostx[]=$v1;
        $datostx[]=$v2;
        $datostx[]=$v3;
        $datost[]=number_format($v1*$v2,2);
        $nombre[$nom]=$datostx;
        $_SESSION["factura"]=$nombre;
    }














echo 1;


}else{
 echo 0;
}
/******************************se ingresa a detalle pedido  *************/




?>