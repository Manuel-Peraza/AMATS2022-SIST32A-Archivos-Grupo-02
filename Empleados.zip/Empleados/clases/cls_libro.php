<?php


class cls_libro extends Database{
    public function ListadoLibros(){
                
        $sql = "select * from libros";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";      
        while($fila=$sentecia->fetch_assoc()){
            $respuesta.="<div class='div-table-row'>";
            $respuesta.="<div class='div-table-cell'>".$fila["idlibro"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["isbn"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["nombre_libro"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["year_publicacion"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["volumen"]."</div>";
            $sql3 = "select * from categoria where id_categoria = ".$fila["id_categoria"]."";  
            $sentecia3 = $this->connect()->Query($sql3);
            while($fila3=$sentecia3->fetch_assoc()){
                $respuesta.="<div class='div-table-cell'>".$fila3["nombre"]."</div>";
            }
            
            $sql2 = "select * from autor where id_autor = ".$fila["idautor"]."";  
            $sentecia2 = $this->connect()->Query($sql2);
            while($fila2=$sentecia2->fetch_assoc()){
                $respuesta.="<div class='div-table-cell'>".$fila2["nombres"].",".$fila2["apellidos"]."-".$fila2["alias_de_autor"]."</div>";
            }
            $respuesta.="
            <div class='div-table-cell'>
            <center>
            <img class='media-object' src='".URL."uploads/".$fila["foto"]."' alt='Libro' width='48' height='48'>
            </center>
            </div>
            ";
            $respuesta.="<div class='div-table-cell'>";
            $respuesta.="<a href='".URL."update_libro/&codigo=".$fila["idlibro"]."' class='btn btn-success'><i class='zmdi zmdi-refresh'></i></a>";
            $respuesta.="</div>";
            $respuesta.="<div class='div-table-cell'>";
            $respuesta.="<a href='".URL."Delete_libro/&codigo=".$fila["idlibro"]."' class='btn btn-danger'><i class='zmdi zmdi-delete'></i></a>";
            $respuesta.="</div>";
            $respuesta.="</div>";
            

    }
    return $respuesta;
    }

    public function ConsultaGeneral($dat){

        
        $sql4 = "select id_autor from autor where nombres = '".$dat["bookName"]."' OR alias_de_autor = '".$dat["bookName"]."'";  
        $sentecia4 = $this->connect()->Query($sql4);
        $respuesta4="";
        while($fila4=$sentecia4->fetch_assoc()){
            $respuesta4.=$fila4["id_autor"];
        }

        $sql = "select * from libros where nombre_libro = '".$dat["bookName"]."' OR  idautor =  '".$respuesta4."'";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";
        while($fila=$sentecia->fetch_assoc()){
            $respuesta.="<div class='media media-hover'>";
            $respuesta.="<div class='media-left media-middle'>";
            $respuesta.="<a href='#!' class='tooltips-general' data-toggle='tooltip' data-placement='right' title='Más información del libro'>";
            $respuesta.="<img class='media-object' src='".URL."uploads/".$fila["foto"]."' alt='Libro' width='48' height='48'>";
            $respuesta.="</a>";
            $respuesta.="</div>";
            $respuesta.="<div class='media-body'>";
            $respuesta.="<h4 class='media-heading'>".$fila["idlibro"]." - ".$fila["nombre_libro"]."</h4>";
            $respuesta.="<div class='pull-left'>";
            $respuesta.="<strong>ISBN: ".$fila["isbn"]."<br>";
            $sql2 = "select * from autor where id_autor = ".$fila["idautor"]."";  
            $sentecia2 = $this->connect()->Query($sql2);
            while($fila2=$sentecia2->fetch_assoc()){
                $respuesta.="<strong>Autor: ".$fila2["nombres"].",".$fila2["apellidos"]."-".$fila2["alias_de_autor"]."<br>";
            }

            $respuesta.="<strong>Año: ".$fila["year_publicacion"]."<br>";
            $respuesta.="<strong>Edición: ".$fila["volumen"]."<br>";
            $sql3 = "select * from categoria where id_categoria = ".$fila["id_categoria"]."";  
            $sentecia3 = $this->connect()->Query($sql3);
            while($fila3=$sentecia3->fetch_assoc()){
                $respuesta.="<strong>Categoria: ".$fila3["nombre"]."<br>";
            }
            $respuesta.="</select>";
            $respuesta.="</div>";
            $respuesta.="<p class='text-center pull-right'>";
            $respuesta.="<a href='#!' class='btn btn-info btn-xs' style='margin-right: 10px;'><i class='zmdi zmdi-info-outline'></i> &nbsp;&nbsp; Más información</a>";
            $respuesta.="</p>";
            $respuesta.="</div>";           


    }
    return $respuesta;

    }

    public function ConsultaLibros(){
        
        $sql = "select * from libros";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";
        while($fila=$sentecia->fetch_assoc()){
            $respuesta.="<div class='media media-hover'>";
            $respuesta.="<div class='media-left media-middle'>";
            $respuesta.="<a href='#!' class='tooltips-general' data-toggle='tooltip' data-placement='right' title='Más información del libro'>";
            $respuesta.="<img class='media-object' src='".URL."uploads/".$fila["foto"]."' alt='Libro' width='70' height='80'>";
            $respuesta.="</a>";
            $respuesta.="</div>";
            $respuesta.="<div class='media-body'>";
            $respuesta.="<h4 class='media-heading'>".$fila["idlibro"]." - ".$fila["nombre_libro"]."</h4>";
            $respuesta.="<div class='pull-left'>";
            $respuesta.="<strong>ISBN: ".$fila["isbn"]."<br>";
            $sql2 = "select * from autor where id_autor = ".$fila["idautor"]."";  
            $sentecia2 = $this->connect()->Query($sql2);
            while($fila2=$sentecia2->fetch_assoc()){
                $respuesta.="<strong>Autor: ".$fila2["nombres"].",".$fila2["apellidos"]."-".$fila2["alias_de_autor"]."<br>";
            }

            $respuesta.="<strong>Año: ".$fila["year_publicacion"]."<br>";
            $respuesta.="<strong>Edicion: ".$fila["volumen"]."<br>";
            $sql3 = "select * from categoria where id_categoria = ".$fila["id_categoria"]."";  
            $sentecia3 = $this->connect()->Query($sql3);
            while($fila3=$sentecia3->fetch_assoc()){
                $respuesta.="<strong>Categoria: ".$fila3["nombre"]."<br>";
            }
            $respuesta.="</select>";
            $respuesta.="</div>";
            $respuesta.="<p class='text-center pull-right'>";
            $respuesta.="<a href='#!' class='btn btn-info btn-xs' style='margin-right: 10px;'><i class='zmdi zmdi-info-outline'></i> &nbsp;&nbsp; Más información</a>";
            $respuesta.="</p>";
            $respuesta.="</div>";           


    }
    return $respuesta;
    
    }

    public function InsertLibro($datos){

        $sql = "INSERT INTO examen3php.libros 
        (isbn, 
        nombre_libro, 
        year_publicacion, 
        volumen, 
        id_categoria, 
        foto, 
        idautor
        )
        VALUES
        ('".$datos["isbn"]."', 
        '".$datos["nombre"]."', 
        '".$datos["año"]."', 
        '".$datos["edicion"]."', 
        '".$datos["categoria"]."', 
        '".$datos["foto"]."', 
        '".$datos["autor"]."'
        ) ";


        $this->connect()->query($sql);
    }

    public function DeleteLibro($dat){

        $sql = "delete from libros where idlibro = ".$dat['codigo']."";
        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }

    public function FiltroConsulta($dat){ 
        $pro=array();
        $pro1=array();
        $pro2=array();
        $pro3=array();
        $pro4=array();
        $pro5=array();
        $pro6=array();
        $datos=array();
        $sql="select * from libros where idlibro = ".$dat["codigo"]."";
        $sentecia=$this->connect()->query($sql);
        while($fila=$sentecia->fetch_assoc()){
            $pro=$fila["isbn"];
            $pro1=$fila["nombre_libro"];
            $pro2=$fila["year_publicacion"];
            $pro3=$fila["volumen"];
            $pro4=$fila["id_categoria"];
            $pro5=$fila["foto"];
            $pro6=$fila["idautor"];
        }
        $datos[]= $pro;
        $datos[]= $pro1;
        $datos[]= $pro2;
        $datos[]= $pro3;
        $datos[]= $pro4;
        $datos[]= $pro5;
        $datos[]= $pro6;

        return $datos;  

    }

    public function UpdateLibro($datos){

        $sql = "update libros SET isbn = '".$datos["isbn"]."', 
        nombre_libro = '".$datos["nombre"]."', 
        year_publicacion = '".$datos["año"]."', 
        volumen = '".$datos["edicion"]."', 
        id_categoria  = '".$datos["categoria"]."', 
        foto = '".$datos["foto"]."', 
        idautor = '".$datos["autor"]."' where idlibro= ".$datos['codigo']."";

        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }
}

?>