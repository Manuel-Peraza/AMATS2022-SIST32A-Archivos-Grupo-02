<?php
class cls_autor extends Database{

    public function ConsultaGeneral(){
                
        $sql = "select * from autor";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";      
        while($fila=$sentecia->fetch_assoc()){
            $respuesta.="<div class='div-table-row'>";
            $respuesta.="<div class='div-table-cell'>".$fila["id_autor"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["nombres"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["apellidos"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["alias_de_autor"]."</div>";
            $respuesta.="<div class='div-table-cell'>";
            $respuesta.="<a href='".URL."update_autores/&codigo=".$fila["id_autor"]."' class='btn btn-success'><i class='zmdi zmdi-refresh'></i></a>";
            $respuesta.="</div>";
            $respuesta.="<div class='div-table-cell'>";
            $respuesta.="<a href='".URL."delete_autores/&codigo=".$fila["id_autor"]."' class='btn btn-danger'><i class='zmdi zmdi-delete'></i></a>";
            $respuesta.="</div>";
            $respuesta.="</div>";
            

    }
    return $respuesta;
    }

    public function ConsultaAutor(){

        
    
        $sql = "select * from autor";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";
        $respuesta.="<select name='autor' class='tooltips-general material-control' data-toggle='tooltip' data-placement='top' title='Elige el proveedor del libro'>";
        while($fila=$sentecia->fetch_assoc()){
            
            //$respuesta.="<td class='count'>".$fila["idAdministracion"]."</td>";
            $respuesta.= "<option value=".$fila["id_autor"].">".$fila["nombres"].".".$fila["apellidos"]."-".$fila["alias_de_autor"]."</td>";
            

    }
    $respuesta.="</select>";
    return $respuesta;
    
    }

    public function InsertAutor($datos){

        $sql = "INSERT INTO `examen3php`.`autor` 
        (`nombres`, 
        `apellidos`, 
        `alias_de_autor`
        )
        VALUES
        ('".$datos['nombre']."', 
        '".$datos['apellido']."', 
        '".$datos['alias']."'
        )";


        $this->connect()->query($sql);
    }

    public function DeleteAutor($dat){

        $sql = "delete from autor where id_autor = ".$dat['codigo']."";
        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }

    public function FiltroConsulta($dat){ 
        $pro=array();
        $pri=array();
        $pru=array();
        $datos=array();
        $sql="select * from autor where id_autor = ".$dat["codigo"]."";
        $sentecia=$this->connect()->query($sql);
        while($fila=$sentecia->fetch_assoc()){
            $pro=$fila["nombres"];
            $pri=$fila["apellidos"];
            $pru=$fila["alias_de_autor"];
        }
        $datos[]= $pro;
        $datos[]= $pri;
        $datos[]= $pru;

        return $datos;  

    }

    public function UpdateAutor($datos){

        $sql = "update autor SET nombres = '".$datos['nombre']."', apellidos = '".$datos['apellido']."', alias_de_autor = '".$datos['alias']."' where id_autor = '".$datos['codigo']."'";
        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }
}



?>