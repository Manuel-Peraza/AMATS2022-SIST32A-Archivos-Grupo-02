<?php


class cls_categorias extends Database{

    public function ConsultaGeneral(){
                
        $sql = "select * from categoria";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";      
        while($fila=$sentecia->fetch_assoc()){
            $respuesta.="<div class='div-table-row'>";
            $respuesta.="<div class='div-table-cell'>".$fila["id_categoria"]."</div>";
            $respuesta.="<div class='div-table-cell'>".$fila["nombre"]."</div>";
            $respuesta.="<div class='div-table-cell'>";
            $respuesta.="<a href='".URL."update_categorias/&codigo=".$fila["id_categoria"]."' class='btn btn-success'><i class='zmdi zmdi-refresh'></i></a>";
            $respuesta.="</div>";
            $respuesta.="<div class='div-table-cell'>";
            $respuesta.="<a href='".URL."delete_categorias/&codigo=".$fila["id_categoria"]."' class='btn btn-danger'><i class='zmdi zmdi-delete'></i></a>";
            $respuesta.="</div>";
            $respuesta.="</div>";
            

    }
    return $respuesta;
    }

    public function ConsultaCategoria(){
 
        $sql = "select * from categoria";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";
        $respuesta.="<select name='categoria' class='tooltips-general material-control' data-toggle='tooltip' data-placement='top' title='Elige la categoría del libro'>";
        while($fila=$sentecia->fetch_assoc()){
           
            //$respuesta.="<td class='count'>".$fila["idAdministracion"]."</td>";
            $respuesta.= "<option value=".$fila["id_categoria"].">".$fila["nombre"]."</td>";
            

    }
    $respuesta.="</select>";
    return $respuesta;
    
    }

    public function ConsultaUpdate($categoria){
 
        $sql = "select * from categoria where id_categoria = '".$categoria['categoria']."'";     
        $sentecia = $this->connect()->Query($sql);
        $respuesta="";
        $respuesta.="<select name='categoria' class='tooltips-general material-control' data-toggle='tooltip' data-placement='top' title='Elige la categoría del libro'>";
        while($fila=$sentecia->fetch_assoc()){
           
            //$respuesta.="<td class='count'>".$fila["idAdministracion"]."</td>";
            $respuesta.= "<option value=".$fila["id_categoria"].">".$fila["nombre"]."</td>";
            

    }
    $respuesta.="</select>";
    return $respuesta;
    
    }

    public function InsertCategoria($dat){

        $sql = "insert into categoria (nombre) values ('".$dat."')";
        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }

    public function UpdateCategoria($dat){

        $sql = "update categoria SET nombre = '".$dat['nombre']."' where id_categoria = '".$dat['codigo']."'";
        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }

    public function DeleteCategoria($dat){

        $sql = "delete from categoria where id_categoria = ".$dat['codigo']."";
        $sentencia = $this-> connect()->query($sql);
        return $sentencia;
    }

    public function FiltroConsulta($dat){ 
        $pro=array();
        $datos=array();
        $sql="select nombre from categoria where id_categoria = ".$dat["codigo"]."";
        $sentecia=$this->connect()->query($sql);
        while($fila=$sentecia->fetch_assoc()){
            $pro=$fila["nombre"];
        }
        $datos[]= $pro;

        return $datos;  

    }
}

?>