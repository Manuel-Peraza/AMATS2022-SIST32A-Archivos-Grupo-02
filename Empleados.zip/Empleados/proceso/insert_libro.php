<?php
$ObjInsert = new cls_libro();
$filename = $_FILES['foto']['name'];
$tempname = $_FILES['foto']['tmp_name'];
$datos["isbn"] = $_POST["isbn"];
$datos["nombre"] = $_POST["nombre"];
$datos["autor"] = $_POST["autor"];
$datos["categoria"] = $_POST["categoria"];
$datos["año"] = $_POST["año"];
$datos["edicion"] = $_POST["edicion"];
$datos["foto"] = $filename;
$ObjInsert->InsertLibro($datos);
move_uploaded_file($tempname,"uploads/".$filename);
?>