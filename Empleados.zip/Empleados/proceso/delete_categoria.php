<?php
$ObjDelete = new cls_categorias();
 $dat['codigo'] =  $_GET['codigo'];
$ObjDelete->DeleteCategoria($dat);
?>