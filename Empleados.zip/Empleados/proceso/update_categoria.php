<?php
$ObjInsert = new cls_categorias();
$dat['nombre']=$_POST['nombre'];
$dat['codigo']=$_GET['codigo'];

var_dump($dat);

$ObjInsert->UpdateCategoria($dat);

?>