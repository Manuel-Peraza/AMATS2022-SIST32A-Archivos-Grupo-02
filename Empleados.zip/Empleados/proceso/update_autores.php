<?php
$ObjInsert = new cls_autor();
$datos['codigo']=$_GET['codigo'];
$datos["nombre"] = $_POST["nombre"];
$datos["apellido"] = $_POST["apellido"];
$datos["alias"] = $_POST["alias"];

$ObjInsert->UpdateAutor($datos);
//var_dump($datos);
?>
