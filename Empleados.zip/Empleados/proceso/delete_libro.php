<?php
$ObjDelete = new cls_libro();
$dat['codigo'] =  $_GET['codigo'];
$ObjDelete->DeleteLibro($dat);
?>