<?php
$ObjInsert = new cls_autor();
$datos["nombre"] = $_POST["nombre"];
$datos["apellido"] = $_POST["apellido"];
$datos["alias"] = $_POST["alias"];

$ObjInsert->InsertAutor($datos);
//var_dump($datos);
?>
