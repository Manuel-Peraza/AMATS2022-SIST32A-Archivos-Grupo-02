<?php
$ObjDelete = new cls_autor();
 $dat['codigo'] =  $_GET['codigo'];
$ObjDelete->DeleteAutor($dat);
?>