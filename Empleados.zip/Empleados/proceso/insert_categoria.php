<?php
$ObjInsert = new cls_categorias();
$dat=$_POST['nombre'];

$ObjInsert->InsertCategoria($dat);

?>