<?php


define("HOST","localhost");
define("USER","root");
define("CLAVE","");
define("DB","examen3php");

?>